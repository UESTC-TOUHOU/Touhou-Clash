import{Z as a,b8 as m}from"./index-ByOEQoFd.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
