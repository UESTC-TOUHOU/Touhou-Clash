import{W as a,b2 as m}from"./index-Bkvu7Phh.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
