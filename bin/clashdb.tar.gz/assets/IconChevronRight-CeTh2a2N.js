import{P as o}from"./index-BPVK8l7-.js";/**
 * @license @tabler/icons-solidjs v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var t=o("outline","chevron-right","ChevronRight",[["path",{d:"M9 6l6 6l-6 6"}]]);export{t as I};
