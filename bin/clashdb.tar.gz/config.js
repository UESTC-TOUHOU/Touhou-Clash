window.__METACUBEXD_CONFIG__ = {
  defaultBackendURL: '',
}
